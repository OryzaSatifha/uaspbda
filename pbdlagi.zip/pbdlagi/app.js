const path = require('path');
const express = require('express');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const mysql = require('mysql');
const app = express();

const connection = mysql.createConnection ( {
    host:'localhost',
    user:'root',
    password: '',
    database : 'node_crud'
});

connection.connect(function(error){
    if(!!error) console.log(error);
    else console.log('Database Connected');
});

//set views file
app.set('views',path.join(__dirname, 'views'));

//set views engine
app.set('view engine', 'ejs');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: false}));

app.get('/',(req, res) => {
   // res.send('CRUD PBD');
   let sql ='SELECT * FROM user';
   let query = connection.query(sql, (err, rows) => {
   if (err) throw err;
   res.render('user_index',{
       title : "CRUD PBD Oryza - Romy - Ratna",
       user : rows
   });
   });
});

app.get('/add',(req, res) => {
    res.render('user_add',{
        title : "CRUD PBD Oryza - Romy - Ratna"
});
});

app.post('/save',(req, res) => { 
    let data = {name: req.body.name, email: req.body.email, phone: req.body.phone};
    let sql = "INSERT INTO user SET ?";
    let query = connection.query(sql, data,(err, results) => {
      if(err) throw err;
      res.redirect('/');
    });
});

app.get('/edit/:userId',(req, res) => {
    const userId = req.params.userId;
    let sql = `Select * from user where id = ${userId}`;
    let query = connection.query(sql,(err, result) => {
        if(err) throw err;
        res.render('user_edit', {
            title : "CRUD PBD Oryza - Romy - Ratna",
            user : result[0]
        });
    });
});

app.post('/update',(req, res) => {
   
    const userId = req.body.id;
    let sql = "update user SET name='"+req.body.name+"',  email='"+req.body.email+"',  phone='"+req.body.phone+"' where id ="+userId;
    let query = connection.query(sql,(err, results) => {
      if(err) throw err;
      res.redirect('/');
    });
});

app.get('/delete/:userId',(req, res) => {
    const userId = req.params.userId;
    let sql = `DELETE from user where id = ${userId}`;
    let query = connection.query(sql,(err, result) => {
        if(err) throw err;
        res.redirect('/');
    });
});

//server listening
app.listen(8000, () => {
    console.log('Server is running at port 8000');
}
);